import random

def mod_exp(base, exp, mod):
    result = 1
    base = base % mod
    while exp > 0:
        if exp % 2 == 1:
            result = (result * base) % mod
        exp = exp // 2
        base = (base * base) % mod
    return result

def diffie_hellman(p, g):
    a = random.randint(2, p-2)
    A = mod_exp(g, a, p)
    return A, a

def compute_shared_secret(A, b, p):
    return mod_exp(A, b, p)

if __name__ == "__main__":
    p = 23
    g = 5

    A, a = diffie_hellman(p, g)
    print("Public key A:", A)

    B, b = diffie_hellman(p, g)
    print("Public key B:", B)

    shared_secret_A = compute_shared_secret(B, a, p)
    shared_secret_B = compute_shared_secret(A, b, p)

    print("Shared secret for A:", shared_secret_A)
    print("Shared secret for B:", shared_secret_B)
