import java.math.BigInteger;
import java.security.SecureRandom;

public class DiffieHellman {

    private static final SecureRandom random = new SecureRandom();

    public static void main(String[] args) {
        BigInteger p = BigInteger.valueOf(23);
        BigInteger g = BigInteger.valueOf(5);

        BigInteger[] resultA = diffieHellman(p, g);
        System.out.println("Public key A: " + resultA[0]);

        BigInteger[] resultB = diffieHellman(p, g);
        System.out.println("Public key B: " + resultB[0]);

        BigInteger sharedSecretA = computeSharedSecret(resultB[0], resultA[1], p);
        BigInteger sharedSecretB = computeSharedSecret(resultA[0], resultB[1], p);

        System.out.println("Shared secret for A: " + sharedSecretA);
        System.out.println("Shared secret for B: " + sharedSecretB);
    }

    public static BigInteger[] diffieHellman(BigInteger p, BigInteger g) {
        BigInteger a = new BigInteger(p.bitLength() - 2, random).add(BigInteger.TWO);
        BigInteger A = g.modPow(a, p);
        return new BigInteger[]{A, a};
    }

    public static BigInteger computeSharedSecret(BigInteger A, BigInteger b, BigInteger p) {
        return A.modPow(b, p);
    }
}
