import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class OTPAuthentication {

    private static Map<String, String> otpStorage = new HashMap<>();

    public static void main(String[] args) {
        String mobileNumber = "1234567890";
        String otp = generateOTP();
        sendOTP(mobileNumber, otp);

        // Simulating user entering OTP
        String enteredOTP = "123456";
        if (authenticateUser(mobileNumber, enteredOTP)) {
            System.out.println("Authentication successful");
        } else {
            System.out.println("Authentication failed");
        }
    }

    public static String generateOTP() {
        Random random = new Random();
        int otpValue = 100000 + random.nextInt(900000); // Generate a 6-digit OTP
        return String.valueOf(otpValue);
    }

    public static void sendOTP(String mobileNumber, String otp) {
        // Simulating sending OTP to mobile number
        System.out.println("OTP sent to " + mobileNumber + ": " + otp);
        otpStorage.put(mobileNumber, otp);
    }

    public static boolean authenticateUser(String mobileNumber, String enteredOTP) {
        String storedOTP = otpStorage.get(mobileNumber);
        if (storedOTP != null && storedOTP.equals(enteredOTP)) {
            otpStorage.remove(mobileNumber); // Remove the OTP from storage
            return true;
        }
        return false;
    }
}
