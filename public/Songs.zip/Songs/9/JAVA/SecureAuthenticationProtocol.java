import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public class SecureAuthenticationProtocol {

    private static final String SHARED_SECRET = "my_secret_key";

    public static void main(String[] args) {
        String username = "user123";
        String password = "password123";

        String challenge = generateChallenge();
        String hashedPassword = hashPassword(password);
        String authenticationToken = generateAuthenticationToken(username, hashedPassword, challenge);

        // Simulating the authentication process
        boolean isAuthenticated = authenticate(username, hashedPassword, challenge, authenticationToken);

        System.out.println("Authenticated: " + isAuthenticated);
    }

    private static String generateChallenge() {
        SecureRandom random = new SecureRandom();
        byte[] bytes = new byte[16];
        random.nextBytes(bytes);
        return Base64.getEncoder().encodeToString(bytes);
    }

    private static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String generateAuthenticationToken(String username, String hashedPassword, String challenge) {
        // This is a simple example, in practice, a more secure method should be used
        return hashPassword(username + hashedPassword + challenge + SHARED_SECRET);
    }

    private static boolean authenticate(String username, String hashedPassword, String challenge, String authenticationToken) {
        String expectedToken = generateAuthenticationToken(username, hashedPassword, challenge);
        return expectedToken.equals(authenticationToken);
    }
}

/**
 * 
 * In this example, the server generates a random challenge and sends it to the client. The client then calculates an authentication token using the challenge, 
 * the hashed password, and a shared secret key. The server verifies the authentication token by recalculating it and comparing it to the received token. 
 * If they match, the client is authenticated.
 */