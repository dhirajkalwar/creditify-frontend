import string

def create_substitution_alphabet(key):
    alphabet = string.ascii_lowercase
    substitution_alphabet = {}
    for i in range(len(alphabet)):
        substitution_alphabet[alphabet[i]] = key[i % len(key)]
    return substitution_alphabet

def encrypt(message, key):
    substitution_alphabet = create_substitution_alphabet(key)
    return ''.join([substitution_alphabet.get(char.lower(), char) for char in message])

def decrypt(ciphertext, key):
    substitution_alphabet = create_substitution_alphabet(key)
    reverse_substitution_alphabet = {v: k for k, v in substitution_alphabet.items()}
    return ''.join([reverse_substitution_alphabet.get(char.lower(), char) for char in ciphertext])

if __name__ == "__main__":
    key = "qwertyuiopasdfghjklzxcvbnm"
    message = "Hello, world!"

    encrypted_message = encrypt(message, key)
    print("Encrypted:", encrypted_message)

    decrypted_message = decrypt(encrypted_message, key)
    print("Decrypted:", decrypted_message)
