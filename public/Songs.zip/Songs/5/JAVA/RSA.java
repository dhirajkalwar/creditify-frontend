import java.math.BigInteger;

public class RSA {

    public static void main(String[] args) {
        BigInteger p = new BigInteger("61");
        BigInteger q = new BigInteger("53");

        BigInteger n = p.multiply(q);
        BigInteger phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));

        BigInteger e = generateE(phi);
        BigInteger d = e.modInverse(phi);

        System.out.println("Public Key: (" + e + ", " + n + ")");
        System.out.println("Private Key: (" + d + ", " + n + ")");

        String message = "Hello, world!";
        BigInteger[] encrypted = encrypt(message, e, n);
        System.out.println("Encrypted message: " + arrayToString(encrypted));

        String decrypted = decrypt(encrypted, d, n);
        System.out.println("Decrypted message: " + decrypted);
    }

    private static BigInteger generateE(BigInteger phi) {
        BigInteger e = BigInteger.valueOf(2);
        while (phi.gcd(e).intValue() > 1) {
            e = e.add(BigInteger.ONE);
        }
        return e;
    }

    private static BigInteger[] encrypt(String message, BigInteger e, BigInteger n) {
        byte[] bytes = message.getBytes();
        BigInteger[] encrypted = new BigInteger[bytes.length];
        for (int i = 0; i < bytes.length; i++) {
            encrypted[i] = BigInteger.valueOf(bytes[i]).modPow(e, n);
        }
        return encrypted;
    }

    private static String decrypt(BigInteger[] encrypted, BigInteger d, BigInteger n) {
        byte[] decrypted = new byte[encrypted.length];
        for (int i = 0; i < encrypted.length; i++) {
            decrypted[i] = encrypted[i].modPow(d, n).byteValue();
        }
        return new String(decrypted);
    }

    private static String arrayToString(BigInteger[] array) {
        StringBuilder sb = new StringBuilder();
        for (BigInteger num : array) {
            sb.append(num.toString()).append(" ");
        }
        return sb.toString();
    }
}
