public class VigenereCipher {

    public static void main(String[] args) {
        String message = "Hello, world!";
        String key = "key";

        String encrypted = encrypt(message, key);
        System.out.println("Encrypted: " + encrypted);

        // String decrypted = decrypt(encrypted, key);
        // System.out.println("Decrypted: " + decrypted);
    }

    public static String encrypt(String message, String key) {
        StringBuilder encrypted = new StringBuilder();
        int keyIndex = 0;
        for (char c : message.toCharArray()) {
            if (Character.isLetter(c)) {
                int shift = Character.toLowerCase(key.charAt(keyIndex % key.length())) - 'a';
                char encryptedChar = (char) ((((Character.toLowerCase(c) - 'a') + shift) % 26) + 'a');
                encrypted.append(Character.isUpperCase(c) ? Character.toUpperCase(encryptedChar) : encryptedChar);
                keyIndex++;
            } else {
                encrypted.append(c);
            }
        }
        return encrypted.toString();
    }

    // public static String decrypt(String encrypted, String key) {
    //     StringBuilder decrypted = new StringBuilder();
    //     int keyIndex = 0;
    //     for (char c : encrypted.toCharArray()) {
    //         if (Character.isLetter(c)) {
    //             int shift = Character.toLowerCase(key.charAt(keyIndex % key.length())) - 'a';
    //             char decryptedChar = (char) ((((Character.toLowerCase(c) - 'a') - shift + 26) % 26) + 'a');
    //             decrypted.append(Character.isUpperCase(c) ? Character.toUpperCase(decryptedChar) : decryptedChar);
    //             keyIndex++;
    //         } else {
    //             decrypted.append(c);
    //         }
    //     }
    //     return decrypted.toString();
    // }
}
