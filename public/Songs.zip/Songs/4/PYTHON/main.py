def encrypt(message, key):
    encrypted = ""
    key_index = 0
    for char in message:
        if char.isalpha():
            shift = ord(key[key_index % len(key)].lower()) - ord('a')
            encrypted += chr((ord(char.lower()) - ord('a') + shift) % 26 + ord('a')).upper() if char.isupper() else chr((ord(char.lower()) - ord('a') + shift) % 26 + ord('a'))
            key_index += 1
        else:
            encrypted += char
    return encrypted

def decrypt(encrypted, key):
    decrypted = ""
    key_index = 0
    for char in encrypted:
        if char.isalpha():
            shift = ord(key[key_index % len(key)].lower()) - ord('a')
            decrypted += chr((ord(char.lower()) - ord('a') - shift) % 26 + ord('a')).upper() if char.isupper() else chr((ord(char.lower()) - ord('a') - shift) % 26 + ord('a'))
            key_index += 1
        else:
            decrypted += char
    return decrypted

if __name__ == "__main__":
    message = "Hello, world!"
    key = "key"
    encrypted = encrypt(message, key)
    print("Encrypted:", encrypted)
    decrypted = decrypt(encrypted, key)
    print("Decrypted:", decrypted)
