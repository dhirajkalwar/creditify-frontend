import java.util.Scanner;

public class BruteForceAttack {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the target password or phrase: ");
        String target = scanner.nextLine();
        System.out.print("Enter the minimum length of the password or phrase: ");
        int minLength = scanner.nextInt();
        System.out.print("Enter the maximum length of the password or phrase: ");
        int maxLength = scanner.nextInt();
        System.out.print("Enable verbose mode? (y/n): ");
        boolean verbose = scanner.next().equalsIgnoreCase("y");

        bruteForce(target, minLength, maxLength, verbose);
    }

    public static void bruteForce(String target, int minLength, int maxLength, boolean verbose) {
        char[] characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
        int[] indices = new int[maxLength];
        StringBuilder builder = new StringBuilder();

        for (int length = minLength; length <= maxLength; length++) {
            bruteForceRecursive(target, characters, indices, 0, length, builder, verbose);
        }
    }

    private static void bruteForceRecursive(String target, char[] characters, int[] indices, int currentIndex, int length, StringBuilder builder, boolean verbose) {
        if (currentIndex == length) {
            String candidate = builder.toString();
            if (verbose) {
                System.out.println("Trying: " + candidate);
            }
            if (candidate.equals(target)) {
                System.out.println("Found match: " + candidate);
            }
            return;
        }

        for (int i = 0; i < characters.length; i++) {
            indices[currentIndex] = i;
            builder.append(characters[i]);
            bruteForceRecursive(target, characters, indices, currentIndex + 1, length, builder, verbose);
            builder.deleteCharAt(builder.length() - 1);
        }
    }
}
