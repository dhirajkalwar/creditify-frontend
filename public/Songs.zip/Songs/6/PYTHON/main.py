import itertools
import string

def brute_force(target, min_length, max_length, verbose=False):
    characters = string.ascii_letters + string.digits
    for length in range(min_length, max_length + 1):
        for candidate in itertools.product(characters, repeat=length):
            candidate_str = ''.join(candidate)
            if verbose:
                print(f"Trying: {candidate_str}")
            if candidate_str == target:
                print(f"Found match: {candidate_str}")
                return

if __name__ == "__main__":
    target = input("Enter the target password or phrase: ")
    min_length = int(input("Enter the minimum length of the password or phrase: "))
    max_length = int(input("Enter the maximum length of the password or phrase: "))
    verbose = input("Do you want to enable verbose mode? (y/n): ").lower() == 'y'
    brute_force(target, min_length, max_length, verbose)
