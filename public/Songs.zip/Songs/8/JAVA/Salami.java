
public class Salami {
    public static void main (String[] args) {
        double eve,bob;
        bob = 45200.75;
        System.out.println("Amount before interest is Credited " + bob);

        double interest = 0.06 * bob;
        bob += interest;
        System.out.println("Amount after interest is Credited " + bob);

        eve = bob - (int)bob;
        bob = (int)bob;
        System.out.println("Eve gets " + eve);
        System.out.println("Amount After Attack is " + bob);



    }
}
