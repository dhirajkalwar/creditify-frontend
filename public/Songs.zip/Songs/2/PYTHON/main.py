def encrypt(message, key):
    ciphertext = [''] * key
    for col in range(key):
        pointer = col
        while pointer < len(message):
            ciphertext[col] += message[pointer]
            pointer += key
    return ''.join(ciphertext)

def decrypt(ciphertext, key):
    num_cols = len(ciphertext) // key
    num_rows = key
    num_full_cols = len(ciphertext) % key
    plaintext = [''] * num_rows
    col = 0
    row = 0
    for symbol in ciphertext:
        plaintext[row] += symbol
        row += 1
        if (row == num_rows) or (row == num_rows - 1 and col >= num_full_cols):
            row = 0
            col += 1
    return ''.join(plaintext)


if __name__ == "__main__":
    message = "Hello, world!"
    key = 4

    encrypted_message = encrypt(message, key)
    print("Encrypted:", encrypted_message)

    decrypted_message = decrypt(encrypted_message, key)
    print("Decrypted:", decrypted_message)
